﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GPEN21_Setup
{
    class AppResources
    {   
        public static bool isNumeric(string str)
        {
            bool retVal = true;

            for (int i = 0; i < str.Length; i++)
            {
                if ((str[i] < 48) || (str[i] > 57))
                {
                    retVal = false;
                }
            }

            return (retVal);
        }

        public static bool isNumeric(char ch)
        {
            bool retVal = false;

            switch(ch)
            {
                case '0':
                case '1':
                case '2':
                case '3':
                case '4':
                case '5':
                case '6':
                case '7':
                case '8':
                case '9':
                    retVal = true;
                    break;
            }

            return (retVal);
        }

        public static string makeNumeric(string str)
        {
            string retVal = "";

            for (int i = 0; i < str.Length; i++)
            {
                if (AppResources.isNumeric(str[i]))
                {
                    retVal += str[i];
                }
            }

            return (retVal);
        }

        public static int power(int baseNum, int exp)
        {
            if (exp == 0)
            {
                return (1);
            }
            else
            {
                return (baseNum * power(baseNum, (exp - 1)));
            }
        }

        public static int strToInt(string str)
        {
            int retVal   = 0;
            int position = (str.Length - 1);

            for (int i = 0; i < str.Length; i++)
            {
                retVal += ((str[i] - 48) * power(10, position));
                position--;
            }

            return (retVal);
        }

        public static string[] appendArray(string[] array, string newItem)
        {
            // Appends a new element in an array to the end of the array.

            // Instantiates an array with a length one element greater than the sent array.
            string[] retVal = new string[array.Length + 1];

            // Iterates through the array.
            for (int i = 0; i < array.Length; i++)
            {
                // Sets the value of the return array at an index to the value of the sent array at the same index.
                retVal[i] = array[i];
            }

            retVal[retVal.Length - 1] = newItem;

            return (retVal);
        }

        public static string[] split(string str, char delim)
        {
            // Splits the sent string into an array of strings based on the delimiter.

            string[] retVal = new string[0];
            string holder   = "";

            // Iterates through the sent string.
            for (int i = 0; i < str.Length; i++)
            {
                // Determines whether or not the char is a delimiter.
                if (str[i] == delim)
                {
                    // Adds the section of text in the holder to the return array, then clears the holder.
                    retVal = AppResources.appendArray(retVal, holder);
                    holder = "";
                }
                else
                {
                    // Adds chars to the holder string.
                    holder += str[i];
                }
            }

            //Sets the last value in the return array to be equal to the new value.
            retVal = AppResources.appendArray(retVal, holder);

            return (retVal);
        }

        public static string formatMACAddress(string str)
        {
            string retVal = "";

            for (int i = 0; i < str.Length; i++)
            {
                if ((((i + 1) % 2) == 0) && (i != (str.Length - 1)))
                {
                    retVal += (str[i] + ":");
                }
                else
                {
                    retVal += str[i];
                }
            }

            return (retVal);
        }

        public static void writeLogFile(string content)
        {
            if (!Directory.Exists(".\\logs"))
            {
                Directory.CreateDirectory(".\\logs");
            }

            StreamWriter ostream = File.AppendText(".\\logs\\log.txt");

            ostream.WriteLine(content);
            ostream.Close();
        }
    }
}
