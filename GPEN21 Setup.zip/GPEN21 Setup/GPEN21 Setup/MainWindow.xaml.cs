﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Management.Automation;
using System.Collections.ObjectModel;
using System.Threading;
using System.IO;

namespace GPEN21_Setup
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// []
    /// </summary>
    public partial class MainWindow : Window
    {
        // Class variables.
        // These variables are resources for the methods in this class.
        private string        username;
        private string        password;
        private string        hostname;
        private string[]      fieldData;
        private PowerShell    psMain;
        private PowerShell    psSecondary;
        private Thread        backgroundProcess;
        private bool          gpenDetected;
        private string        workingDirectory;
        private bool          updateChecked;
        private bool          configurationProcessRunning;
        private string        log;
        private delegate void detect_gpen21_callback(int state);
        private delegate void logger_callback(string content);
        private delegate void messagebox_callback(string content);
        private delegate void increment_vlan_callback();
        private delegate void disable_user_input_callback();
        private delegate void enable_user_input_callback();

        public MainWindow()
        {
            // Constructor.
            InitializeComponent(); // Initializes GUI.

            this.log = "";

            if (Directory.Exists("C:\\Users\\" + Environment.UserName + "\\AppData\\Local\\GPEN21_Setup") && File.Exists("C:\\Users\\" + Environment.UserName + "\\AppData\\Local\\GPEN21_Setup\\data"))
            {
                string [] fieldData = AppResources.split(File.ReadAllText("C:\\Users\\" + Environment.UserName + "\\AppData\\Local\\GPEN21_Setup\\data"), ':');

                usernameTextBox.Text = fieldData[0];
                passwordTextBox.Text = fieldData[1];
                IPAddress.Text       = fieldData[2];
                VLANTextBox.Text     = fieldData[3];
                POPIDTextBox.Text    = fieldData[4];
                POPMangTextBox.Text  = fieldData[5];
            }

            LOG.IsReadOnly = true;

            this.psSecondary = PowerShell.Create(); // Instantiates the PowerShell Object that will be used in the background process.

            this.configurationProcessRunning = false;

            //GPEN21 Login Information.
            this.username         = "admin";
            this.password         = "";
            this.hostname         = IPAddress.Text;
            this.gpenDetected     = false;

            // Current Working Directory.
            this.workingDirectory = this.psSecondary.AddScript("$workingDirectory = (cmd /c cd); $workingDirectory").Invoke()[0].BaseObject.ToString();

            // Background process used to detect the GPEN21.
            this.backgroundProcess = new Thread(() =>
            {
                Thread.CurrentThread.IsBackground = true;

                backgroundDetectGPEN21();
            });

            // Starts the background process that detects the GPEN21.
            this.backgroundProcess.Start();

            DateTime currentTime = DateTime.Now;

            logger(
                "> "
                + AppResources.addPreceedingZeros(currentTime.Year.ToString(), 4)
                + AppResources.addPreceedingZeros(currentTime.Month.ToString(), 2)
                + AppResources.addPreceedingZeros(currentTime.Day.ToString(), 2)
                + AppResources.addPreceedingZeros(currentTime.Hour.ToString(), 2)
                + AppResources.addPreceedingZeros(currentTime.Minute.ToString(), 2)
                + AppResources.addPreceedingZeros(currentTime.Second.ToString(), 2)
                + " : Current User = " + Environment.UserName 
                + "\nMachine Name = " + Environment.MachineName 
                + "\nDate & Time = " + DateTime.Now.ToString("MM/dd/yyyy HH:mm:ss"));
        }

        ~MainWindow()
        {
            // Deconstructor.
            // Only executes when the application is terminated and resources are being deallocated.

            // This ensures that the background thread is stopped when the program terminates.
            if (Directory.Exists("C:\\Users\\" + Environment.UserName + "\\AppData\\Local\\GPEN21_Setup"))
            {
                File.WriteAllText(("C:\\Users\\" + Environment.UserName + "\\AppData\\Local\\GPEN21_Setup\\data"), (this.fieldData[0] + ":" + this.fieldData[1] + ":" + this.fieldData[2] + ":" + this.fieldData[3] + ":" + this.fieldData[4] + ":" + this.fieldData[5]));
            }
            else
            {
                Directory.CreateDirectory("C:\\Users\\" + Environment.UserName + "\\AppData\\Local\\GPEN21_Setup");
                File.WriteAllText(("C:\\Users\\" + Environment.UserName + "\\AppData\\Local\\GPEN21_Setup\\data"), (this.fieldData[0] + ":" + this.fieldData[1] + ":" + this.fieldData[2] + ":" + this.fieldData[3] + ":" + this.fieldData[4] + ":" + this.fieldData[5]));
            }

            AppResources.writeLogFile(this.log);

            this.backgroundProcess.Abort();
        }
        private void backgroundDetectGPEN21()
        {
            // Continuously pings the GPEN21 to determine whether or not it is connected to the network.
            // The hostname is pinged with one byte of data and a maximum timeout of 1ms.
            // Any device on the local network should respond within this amount of time.
            // This is meant to reduce the network utilization of the application.
            // It should show 0Mbps in the task manager while it is running even though it is actively checking the connection.

            while (true) // This is an infinite loop. It will run until the thread is aborted.
            {
                try
                {
                    if (!gpenConnected(this.psSecondary.AddScript("$pingout = (cmd /c ping " + hostname + " -n 1 -w 10 -l 1); $pingout").Invoke()[2].BaseObject.ToString(), hostname))
                    {
                        //Updates the UI in the main thread to reflect the Disconnected Status of the device.
                        Dispatcher.BeginInvoke(new detect_gpen21_callback(detection), System.Windows.Threading.DispatcherPriority.Render, new object[] { 0 });
                    }
                    else
                    {
                        //Updates the UI in the main thread to reflect the Connected Status of the device.
                        Dispatcher.BeginInvoke(new detect_gpen21_callback(detection), System.Windows.Threading.DispatcherPriority.Render, new object[] { 1 });
                    }
                }
                catch(Exception e)
                {
                    Thread.Sleep(5000);
                }

                //A 5 second wait produced the best connect/disconnect detection time.
                Thread.Sleep(1000);
            }
        }

        private void detection(int state)
        {
            // Updates the UI to reflect connection/disconnection status.

            switch (state)
            {
                case 0:
                    if (this.gpenDetected)
                    {
                        this.gpenDetected = false;

                        // The Uri Object cannot use relative paths.
                        // The current working directory has to be gotten and inserted into a string, then converted into a UriString object then passed to the Uri Object.
                        NotConnectedImage.Source = new BitmapImage(new Uri(uriString: (this.workingDirectory + "\\Disconnected.png")));
                        ConnectivityNotification.Content = "Not Connected!";
                    }
                    break;
                case 1:
                    if (!this.gpenDetected)
                    {
                        gpenDetected = true;

                        // The Uri Object cannot use relative paths.
                        // The current working directory has to be gotten and inserted into a string, then converted into a UriString object then passed to the Uri Object.
                        NotConnectedImage.Source = new BitmapImage(new Uri(uriString: (this.workingDirectory + "\\Connected.png")));
                        ConnectivityNotification.Content = "Connected!";
                    }
                    break;
            }
        }

        private void numeric_text_filter(object sender, KeyEventArgs e)
        {
            // Does not allow any characters other than numeric characters 0-9 to be entered into the text box.
            int keyboardKey = ((int)e.Key);

            // Determines whether or not the key pressed on the keyboard was one of the keys 0-9.
            // Keys 0-9 have ids 34-43 or 74-83 depending on whether or not the key was pressed on the numberpad or on the number row.
            if (!((keyboardKey >= 34) && (keyboardKey <= 43)) && !((keyboardKey >= 74) && (keyboardKey <= 83)))
            {
                // Some non numeric key presses need to be handeled.
                // If the tab button is pressed, which has an id of 3, the event is allowed to complete beyond this event handler.
                // Shift tab will also work.
                switch(keyboardKey)
                {
                    default:
                        e.Handled = true;
                        break;
                    case 3:
                        e.Handled = false;
                        break;
                    case 88:
                    case 144:
                        if ((sender as TextBox).Name.Equals("IPAddress"))
                        {
                            e.Handled = false;
                        }
                        else 
                        {
                            e.Handled = true;
                        }
                        break;
                }
            }

            this.fieldData = new string[6] { usernameTextBox.Text, passwordTextBox.Text, IPAddress.Text, VLANTextBox.Text, POPIDTextBox.Text, POPMangTextBox.Text };
        }

        private void whitespace_change_event(object sender, TextChangedEventArgs e)
        {
            // This event handler executes on text change.
            // This event handler is used by the vlan text box and the POPID text box, so the sender object has to b e converted to a TextBox object.
            // This event removes space characters from the text box.

            TextBox senderObject    = sender as TextBox;
            string  noWhiteSpace    = "";
            int     selectionStart  = senderObject.SelectionStart;

            // Iterates through the text in the text box, and sets the noWhiteSpace string to be equal to the text in the text box without the space characters.
            for(int i = 0; i < senderObject.Text.Length; i++)
            {
                if (senderObject.Text[i] != 32)
                {
                    noWhiteSpace += senderObject.Text[i];
                }
            }

            // Sets the text box text to be equal to the noWhiteSpace string.
            // Moves the cursor in the text box to the end of the text in the text box.
            senderObject.Text            = noWhiteSpace;

            int enteredNumber = AppResources.strToInt(AppResources.makeNumeric(senderObject.Text));

            switch (senderObject.MaxLength)
            {
                case 3:
                    if (((enteredNumber < 1) || (enteredNumber > 255)) && (senderObject.Text.Length > 0))
                    {
                        if (enteredNumber > 255)
                        {
                            senderObject.Text = "255";
                        }
                        else if (enteredNumber < 1)
                        {
                            senderObject.Text = "1";
                        }
                    }
                    break;
                case 4:
                    if (((enteredNumber < 1501) || (enteredNumber > 3500)) && (senderObject.Text.Length == senderObject.MaxLength))
                    {
                        if (enteredNumber > 3500)
                        {
                            senderObject.Text = "3500";
                        }
                        else if (enteredNumber < 1501)
                        {
                            senderObject.Text = "1501";
                        }
                    }
                    break;
            }

            if ((usernameTextBox != null) && (passwordTextBox != null) && (IPAddress != null) && (VLANTextBox != null) && (POPIDTextBox != null) && (POPMangTextBox != null))
            {
                this.fieldData = new string[6] { usernameTextBox.Text, passwordTextBox.Text, IPAddress.Text, VLANTextBox.Text, POPIDTextBox.Text, POPMangTextBox.Text };
            }

            senderObject.SelectionStart  = selectionStart;
            senderObject.SelectionLength = 0;

            e.Handled = true;
        }

        private void make_uppercase_onchange(object sender, TextChangedEventArgs e)
        {
            TextBox senderObject = sender as TextBox;
            int selectionStart   = senderObject.SelectionStart;

            senderObject.Text            = (sender as TextBox).Text.ToUpper();
            senderObject.SelectionStart  = selectionStart;
            senderObject.SelectionLength = 0;

            this.fieldData = new string[4] { IPAddress.Text, VLANTextBox.Text, POPIDTextBox.Text, POPMangTextBox.Text };

            e.Handled = true;
        }

        private void update_username_onchange(object sender, TextChangedEventArgs e)
        {
            this.username = (sender as TextBox).Text;

            if ((usernameTextBox != null) && (passwordTextBox != null) && (IPAddress != null) && (VLANTextBox != null) && (POPIDTextBox != null) && (POPMangTextBox != null))
            {
                this.fieldData = new string[6] { usernameTextBox.Text, passwordTextBox.Text, IPAddress.Text, VLANTextBox.Text, POPIDTextBox.Text, POPMangTextBox.Text };
            }
        }

        private void update_password_onchange(object sender, TextChangedEventArgs e)
        {
            this.password = (sender as TextBox).Text;

            if ((usernameTextBox != null) && (passwordTextBox != null) && (IPAddress != null) && (VLANTextBox != null) && (POPIDTextBox != null) && (POPMangTextBox != null))
            {
                this.fieldData = new string[6] { usernameTextBox.Text, passwordTextBox.Text, IPAddress.Text, VLANTextBox.Text, POPIDTextBox.Text, POPMangTextBox.Text };
            }
        }

        private void update_ip_onchange(object sender, TextChangedEventArgs e)
        {
            TextBox senderObject = (sender as TextBox);
            int selectionStart   = senderObject.SelectionStart;

            string[] correction         = AppResources.correctIP(senderObject.Text);
            senderObject.Text           = correction[0];
            senderObject.SelectionStart = (selectionStart - (AppResources.strToInt(correction[1])));

            try
            {
                if (this.gpenDetected)
                {
                    NotConnectedImage.Source = new BitmapImage(new Uri(uriString: (this.workingDirectory + "\\Disconnected.png")));
                    this.gpenDetected        = false;
                }
            }
            catch (Exception ex)
            {
                //Do Nothing. . .
            }

            ConnectivityNotification.Content = "Searching for IP. . .";
            this.hostname                    = senderObject.Text;
            
            if ((usernameTextBox != null) && (passwordTextBox != null) && (IPAddress != null) && (VLANTextBox != null) && (POPIDTextBox != null) && (POPMangTextBox != null))
            {
                this.fieldData = new string[6] { usernameTextBox.Text, passwordTextBox.Text, IPAddress.Text, VLANTextBox.Text, POPIDTextBox.Text, POPMangTextBox.Text };
            }
        }

        private void textbox_focus_event(object sender, EventArgs e)
        {
            TextBox senderObject = (sender as TextBox);

            senderObject.SelectAll();
        }

        private void correct_vlan_lost_focus_event(object sender, EventArgs e)
        {
            TextBox senderObject = sender as TextBox;

            string noWhiteSpace = "";
            int selectionStart  = senderObject.SelectionStart;

            // Iterates through the text in the text box, and sets the noWhiteSpace string to be equal to the text in the text box without the space characters.
            for (int i = 0; i < senderObject.Text.Length; i++)
            {
                if (senderObject.Text[i] != 32)
                {
                    noWhiteSpace += senderObject.Text[i];
                }
            }

            // Sets the text box text to be equal to the noWhiteSpace string.
            // Moves the cursor in the text box to the end of the text in the text box.
            senderObject.Text = noWhiteSpace;

            int enteredNumber = AppResources.strToInt(AppResources.makeNumeric(senderObject.Text));

            if ((enteredNumber < 1501) || (enteredNumber > 3500))
            {
                if (enteredNumber > 3500)
                {
                    senderObject.Text = "3500";
                }
                else if (enteredNumber < 1501)
                {
                    senderObject.Text = "1501";
                }
            }

            if ((usernameTextBox != null) && (passwordTextBox != null) && (IPAddress != null) && (VLANTextBox != null) && (POPIDTextBox != null) && (POPMangTextBox != null))
            {
                this.fieldData = new string[6] { usernameTextBox.Text, passwordTextBox.Text, IPAddress.Text, VLANTextBox.Text, POPIDTextBox.Text, POPMangTextBox.Text };
            }

            senderObject.SelectionStart = selectionStart;
            senderObject.SelectionLength = 0;
        }

        private void logger(string content)
        {
            // Writes to the log which is currently a TextBox in the UI window.
            // Currently used for testing purposes.
            // Can be used like STDOUT in a console application.

            //Determines whether or not there is already stuff in the log.
            if (LOG.Text.ToString().Length > 0)
            {
                // If there is, then a new line is appended.
                LOG.Text += "\n";
            }

            LOG.Text += content;
            this.log = LOG.Text;

            LOG.ScrollToEnd();
        }


        private void background_logger(string content)
        {
            Dispatcher.BeginInvoke(new logger_callback(logger), System.Windows.Threading.DispatcherPriority.Render, new object[] { content });
        }

        private void background_messageBox(string content)
        {
            Dispatcher.BeginInvoke(new messagebox_callback((string message) => {
                MessageBox.Show(message);
            }), System.Windows.Threading.DispatcherPriority.Render, new object[] { content });
        }

        private bool gpenConnected(string ping, string hostname)
        {
            //Pings the IP given and looks for "Reply from {IP}" in the output of the ping command to determine whether or not the IP is in the network.
            
            return (AppResources.split(ping, ':')[0].Equals("Reply from " + hostname));
        }

        private void incrementVLAN()
        {
            if ((VLANTextBox.Text.Length > 0) && AppResources.isNumeric(VLANTextBox.Text))
            {
                VLANTextBox.Text = (Int32.Parse(VLANTextBox.Text) + 1).ToString();
            }
            else
            {
                MessageBox.Show("Error: '" + VLANTextBox.Text + "' is not numeric.");
            }
        }

        private void Increment_VLAN(object sender, RoutedEventArgs e)
        {
            this.incrementVLAN();
        }

        private void background_increment_vlan()
        {
            Dispatcher.BeginInvoke(new increment_vlan_callback(incrementVLAN), System.Windows.Threading.DispatcherPriority.Render, new object[] { });
        }

        private void disable_user_input()
        {
            usernameTextBox.IsReadOnly = true;
            passwordTextBox.IsReadOnly = true;
            IPAddress.IsReadOnly       = true;
            VLANTextBox.IsReadOnly     = true;
            POPIDTextBox.IsReadOnly    = true;
            POPMangTextBox.IsReadOnly  = true;

            updateBox.IsEnabled           = false;
            GOButton.IsEnabled            = false;
            IncrementVLANButton.IsEnabled = false;
        }

        private void enable_user_input()
        {
            usernameTextBox.IsReadOnly = false;
            passwordTextBox.IsReadOnly = false;
            IPAddress.IsReadOnly       = false;
            VLANTextBox.IsReadOnly     = false;
            POPIDTextBox.IsReadOnly    = false;
            POPMangTextBox.IsReadOnly  = false;

            updateBox.IsEnabled           = true;
            GOButton.IsEnabled            = true;
            IncrementVLANButton.IsEnabled = true;
        }

        private void background_disable_user_input()
        {
            Dispatcher.BeginInvoke(new disable_user_input_callback(disable_user_input), System.Windows.Threading.DispatcherPriority.Render, new object[] { });
        }

        private void background_enable_user_input()
        {
            Dispatcher.BeginInvoke(new enable_user_input_callback(enable_user_input), System.Windows.Threading.DispatcherPriority.Render, new object[] { });
        }



        private void Setup_GPEN21(object sender, RoutedEventArgs e)
        {
            // This function attempts to log into the IP address and get the mac address from the sys.b output from the IP over HTTP.
            // If it does not get anything, then the device is not a GPEN21 and this function fails.
            // If it does get a mac address back from the IP, then it is safe to assume that it is a GPEN21.

            this.updateChecked = (bool)updateBox.IsChecked;

            // The following code executes if the GPEN21 is detected.

            this.psMain = PowerShell.Create(); // Instantiates the PowerShell Object that will be used in the main process.
            this.psMain.AddScript(System.IO.File.ReadAllText(@".\GPEN21 Config.ps1")).Invoke();
            this.psMain.AddCommand("GPEN21-MAC")
                .AddParameter("User", username)
                .AddParameter("Password", password)
                .AddParameter("Hostname", hostname);

            this.logger("Getting MAC Address of GPEN at " + hostname + ". . .");

            try
            {
                string gpenMac = this.psMain.Invoke()[0].BaseObject.ToString();

                // If at this point the MAC Address length is greater than 0, then it is safe to assume that the IP is a GPEN21.
                // The program can continue.
                if (gpenMac.Length > 0)
                {
                    if (this.updateChecked)
                    {
                        this.background_logger("Updating GPEN21. . .");

                        this.psMain.AddCommand("Update-GPEN21")
                            .AddParameter("User", this.username)
                            .AddParameter("Password", this.password)
                            .AddParameter("Hostname", this.hostname)
                            .Invoke();
                    }

                    Thread configurationThread = new Thread(() => {
                        this.background_logger("MAC Address of GPEN21 at " + hostname + " = " + AppResources.formatMACAddress(gpenMac.Substring(1, gpenMac.Length - 2)) + ".");

                        string[] names = new string[] { "VLAN (1501 - 3547)", "POP ID", "POP Management #" };
                        string errors = "";

                        // Checks to make sure that all of the required fields are filled out.
                        for (int i = 2; i < this.fieldData.Length; i++)
                        {
                            if (this.fieldData[i].Length == 0)
                            {
                                // Loggs the name of the required field that was not field out.
                                if (errors.Length > 0)
                                {
                                    errors += "\n";
                                }

                                errors += "\"" + names[i - 1] + "\" is a required field.";
                            }
                        }

                        if (errors.Length > 0)
                        {
                            // Displays the errors detected.
                            background_logger("Error!\n" + errors);
                            background_messageBox(errors);
                        }
                        else
                        {
                            // Generates the configuration file for the GPEN21 and stores it in the current working directory.
                            background_logger("Generating Configuration File. . .");

                            string configPath = this.psMain.AddScript("genConfig(" + this.fieldData[3] + ", \"" + this.fieldData[4] + "\",\"" + this.fieldData[5] + "\",\"" + gpenMac + "\");").Invoke()[0].BaseObject.ToString();

                            this.psMain.AddCommand("RESTOREBACKUP-GPEN21")
                                .AddParameter("User", this.username)
                                .AddParameter("Password", this.password)
                                .AddParameter("Path", configPath)
                                .AddParameter("Hostname", this.hostname)
                                .Invoke();

                            background_logger("The configuration file was successfully generated and saved at " + configPath + "\nRebooting GPEN21 at " + hostname + ". . .");

                            background_logger("Rebooting GPEN21. . .");
                            this.psMain.AddCommand("Reboot-GPEN21")
                                .AddParameter("User", this.username)
                                .AddParameter("Password", this.password)
                                .AddParameter("Hostname", this.hostname)
                                .Invoke();

                            background_logger("Configuration complete.");
                            background_messageBox("Configuration Complete.");
                            background_logger("\r");
                            background_increment_vlan();
                        }

                        this.configurationProcessRunning = false;
                    });

                    configurationThread.Start();
                }
                else
                {
                    // Displays an error notifying the user that the GPEN21 could not be connected to.
                    logger("Error! Verify the connection to the GPEN21.");
                    MessageBox.Show("Error! Verify the connection to the GPEN21.");
                }
            }
            catch (ArgumentOutOfRangeException exception)
            {
                MessageBox.Show("ERROR: Unable to obtain a MAC Address. Please verify the GPEN21's IP Address.\n\nPossible Causes:\n\tThe GPEN21 is not connected to the network.\n\tThe GPEN21 is not using the IP Address " + this.hostname + ".\n\tThe GPEN21 has a password set on the admin login.");
            }
        }

        private void vlan_text_change_event(object sender, TextChangedEventArgs e)
        {

        }
    }
}
