﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Management.Automation;
using System.Collections.ObjectModel;
using System.Threading;

namespace GPEN21_Setup
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// []
    /// </summary>
    public partial class MainWindow : Window
    {
        private string        username;
        private string        password;
        private string        hostname;
        private PowerShell    psMain;
        private PowerShell    psSecondary;
        private Thread        backgroundProcess;
        private Boolean       gpenDetected;
        private delegate void detect_gpen21_callback(int state);

        public MainWindow()
        {
            // Constructor.
            InitializeComponent(); // Initializes GUI.

            this.psMain      = PowerShell.Create(); // Instantiates the PowerShell Object.
            this.psSecondary = PowerShell.Create();

            //GPEN21 Login Information.
            this.username = "admin";
            this.password = "";
            this.hostname = "192.168.1.79";
            this.gpenDetected = false;

            // Background process used to detect the GPEN21.
            this.backgroundProcess = new Thread(() =>
            {
                Thread.CurrentThread.IsBackground = true;

                backgroundDetectGPEN21();
            });

            // Starts the background process that detects the GPEN21.
            this.backgroundProcess.Start();
        }

        ~MainWindow()
        {
            // Deconstructor.
            // This ensures that the background thread is stopped when the program terminates.
            this.backgroundProcess.Abort();
        }

        private void backgroundDetectGPEN21()
        {
            // Continuously pings the GPEN21 to determine whether or not it is connected to the network.
            while (true)
            {
                if (!gpenConnected(this.psSecondary.AddScript("$pingout = (cmd /c ping " + hostname + " -n 1 -w 500); $pingout").Invoke()[2].BaseObject.ToString(), hostname))
                {
                    Dispatcher.BeginInvoke(new detect_gpen21_callback(detection), System.Windows.Threading.DispatcherPriority.Render, new object[] { 0 });
                    Thread.Sleep(1000);
                }
                else
                {
                    Dispatcher.BeginInvoke(new detect_gpen21_callback(detection), System.Windows.Threading.DispatcherPriority.Render, new object[] { 1 });
                    Thread.Sleep(650);
                }
            }
        }

        private void detection(int state)
        {
            // Detects the presence of a GPEN21 in the network by pinging the GPEN21 and looking for the term "Reply from {ip}".
            switch(state)
            {
                case 0:
                    this.gpenDetected = false;

                    // For some reason the Uri object is only accepting relative paths. I have to figure out how to get the Uri object to accept a relative path.
                    NotConnectedImage.Source = new BitmapImage(new Uri(@"C:\Users\ncabral\Documents\GPEN21 Files\GPEN21 Setup\Disconnected.png"));
                    ConnectivityNotification.Content = "GPEN21 Not Connected!";
                    break;
                case 1:
                    gpenDetected = true;

                    // For some reason the Uri object is only accepting relative paths. I have to figure out how to get the Uri object to accept a relative path.
                    NotConnectedImage.Source = new BitmapImage(new Uri(@"C:\Users\ncabral\Documents\GPEN21 Files\GPEN21 Setup\Connected.png"));
                    ConnectivityNotification.Content = "GPEN21 Connected!";
                    break;
            }
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Not currently used.
        }

        private void logger(string content)
        {
            // Writes to the log which is currently a TextBox in the UI window.
            // Currently used for testing purposes.
            // Can be used like STDOUT in a console application.
            if (LOG.Text.ToString().Length > 0)
            {
                LOG.Text += "\n";
            }

            LOG.Text += content;
        }

        private string[] appendArray(string[] array, string newItem)
        {
            // Appends a new element in an array to the end of the array.
            string[] retVal = new string[array.Length + 1];

            for (int i = 0; i < array.Length; i++)
            {
                retVal[i] = array[i];
            }

            retVal[retVal.Length - 1] = newItem;

            return (retVal);
        }

        private string[] split(string str, char delim)
        {
            // Splits a string into an array of strings based on the delimiter.
            string[] retVal = new string[0];
            string   holder = "";

            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] == delim)
                {
                    retVal = appendArray(retVal, holder);
                    holder = "";
                }
                else
                {
                    holder += str[i];
                }
            }

            retVal = appendArray(retVal, holder);

            return (retVal);
        }

        private Boolean gpenConnected(string ping, string hostname)
        {
            //Pings the IP given and looks for "Reply from {IP}" in the output of the ping command to determine whether or not the IP is in the network.
            return (split(ping, ':')[0].Equals("Reply from " + hostname));
        }

        private void Setup_GPEN21(object sender, RoutedEventArgs e)
        {
            // This function attempts to log into the IP address and get the mac address from the sys.b output from the IP over HTTP.
            // If it does not get anything, then the device is not a GPEN21 and this function fails.
            // If it does get a mac address back from the IP, then it is safe to assume that it is a GPEN21.
            if (this.gpenDetected)
            {
                this.psMain.AddScript(System.IO.File.ReadAllText(@".\GPEN21 Config.ps1")).Invoke();
                this.psMain.AddCommand("GPEN21-MAC")
                    .AddParameter("User", username)
                    .AddParameter("Password", password)
                    .AddParameter("Hostname", hostname);

                logger("Getting MAC Address of GPEN at " + hostname + ". . .");

                string gpenMac = this.psMain.Invoke()[0].BaseObject.ToString();

                // If at this point the MAC Address length is greater than 0, then it is safe to assume that the IP is a GPEN21.
                if (gpenMac.Length > 0)
                {
                    logger("MAC Address of GPEN21 at " + hostname + " is " + gpenMac + ".");
                    string[] names = new string[] { "VLAN (1501 - 3547)", "POP Management #", "POP ID" };
                    string[] userInput = new string[] { VLANTextBox.Text, POPMangTextBox.Text, POPIDTextBox.Text.ToUpper() };
                    string errors = "";

                    for (int i = 0; i < userInput.Length; i++)
                    {
                        if (userInput[i].Length == 0)
                        {
                            if (errors.Length > 0)
                            {
                                errors += "\n";
                            }

                            errors += "\"" + names[i] + "\" is a required field.";
                        }
                    }

                    if (errors.Length > 0)
                    {
                        logger("Error!\n" + errors);
                        MessageBox.Show(errors);
                    }
                    else
                    {
                        logger("Generating Configuration File. . .");
                        string configPath = this.psMain.AddScript("genConfig(" + userInput[0] + ", " + userInput[1] + ",\"" + userInput[2] + "\",\"" + gpenMac + "\");").Invoke()[0].BaseObject.ToString();
                        this.psMain.AddCommand("RESTOREBACKUP-GPEN21")
                            .AddParameter("User", username)
                            .AddParameter("Password", password)
                            .AddParameter("Path", configPath)
                            .AddParameter("Hostname", hostname)
                            .Invoke();

                        logger("The configuration file was successfully generated and saved at " + configPath + "\nRebooting GPEN21 at " + hostname + ". . .");

                        this.psMain.AddCommand("Reboot-GPEN21")
                            .AddParameter("User", username)
                            .AddParameter("Password", password)
                            .AddParameter("Hostname", hostname)
                            .Invoke();

                        logger("Configuration complete.");
                    }
                }
                else
                {
                    logger("Error! Verify the connection to the GPEN21.");
                    MessageBox.Show("Error! Verify the connection to the GPEN21.");
                }
            }
            else
            {
                MessageBox.Show("There is not currently a GPEN21 connected!");
            }
        }
    }
}
